import discord
import requests
import random
from colorama import Fore
from configparser import ConfigParser
import pathlib


intents = discord.Intents.default()
intents.message_content = True
client = discord.Client(intents=intents)
config_path = pathlib.Path(__file__).parent.absolute() / "config.ini"
config = ConfigParser()
config.read(config_path)

Token = config['Authentication']['Token']

class Person(object):

    def __init__(self, data):
        self.__dict__ = data


@client.event
async def on_ready():
    print(Fore.GREEN + 'logged in as {0.user}'.format(client))


@client.event
async def on_message(message):
    if message.author == client.user:
        return

    if message.content.startswith('$PDD'):
        MessageNum = random.randint(1, 6)
        if MessageNum == 1:
            Message = "PDD is so sexy fr"
        if MessageNum == 2:
            Message = "PDD is currently 800k Value"
        if MessageNum == 3:
            Message = "Ryaxg is daddy"
        if MessageNum == 4:
            Message = "PDD is indeed Pink"
        if MessageNum == 5:
            Message = "PDD stands for Pink Diamond Domination >:)"

        if MessageNum == 6:
            Message = "Did you know PDD was crafted with 99% pink diamonds and 1% plastic?"

        await message.channel.send(Message)

    if message.content.startswith('$dice'):
        DiceNum = random.randint(1, 6)

        await message.channel.send(f"You rolled a {DiceNum}")
    if message.content.startswith('$coinflip'):
        CoinNum = random.randint(1, 2)
        if CoinNum == 1:
            Coin = "Heads"
        if CoinNum == 2:
            Coin = "Tails"

        await message.channel.send(f"{Coin}")
    if message.content.startswith('$value'):
        print(message.content)
        messagecontent = message.content
        split_message = messagecontent.split()
        username = split_message[1]

        Res = requests.get(
            f'https://users.roblox.com/v1/users/search?keyword={username}')
        if Res.status_code != 200:
            print(Fore.RED + str(Res.status_code))
        else:
            print(Fore.LIGHTGREEN_EX + str(Res.status_code))
            print(Fore.WHITE + str(type(Res.json())))
            Apijson = Res.json()
            print(Apijson['data'][0]['id'])
            UserId = (Apijson['data'][0]['id'])
            print(UserId)
        Req = requests.get(
            f"https://www.rolimons.com/playerapi/player/{UserId}")
        if Req.status_code != 200:
            print(Req.status_code)
        else:

            PlrData = Req.json()

            PlrValue = PlrData['value']
            PlrRap = PlrData['rap']

            TotalValue = ("{:,}".format(int(PlrValue)))
            TotalRap = ("{:,}".format(int(PlrRap)))

            await message.channel.send(
                f"{username}, You Have {TotalValue} Value and {TotalRap} Rap!")

    if message.content.startswith('$cat'):
        print(message.author)
        req = requests.get('https://api.thecatapi.com/v1/images/search')
        if req.status_code == 200:
            print(type(req.json()[0]))
        for item in req.json():
            person = Person(item)
            print(person.url)
        else:
            print(req.status_code)

        await message.channel.send(str(person.url))


client.run(Token)
