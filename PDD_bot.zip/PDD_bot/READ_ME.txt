Thanks for installing PDD bot!

Commands list:

$value {players username} #Grabs a players rolimons value and rap
$cat #posts a random cat image
$coinflip #heads or tails!
$dice #rolls a number 1-6
$PDD #random facts about PDD

Make sure to run the InstallModules.bat and put your bot token in the config file before running

**Notice: to get a discord bot token go to https://discord.com/developers/applications and select new application, 
  after that you need to go down to the intents of the bot and turn them all on. Then copy the token it gives you and paste it into the token section in config.ini**